# SABI — Site GitHub Pages

Site statique prêt à être publié sur GitHub Pages.

## Structure

- `index.html` : structure et contenu des sections.
- `css/sabi.css` : apparence, responsive et thème.
- `js/sabi.js` : navigation, dossiers, rapports, notifications, recherche, sauvegarde locale et espace agents.
- `.nojekyll` : permet à GitHub Pages de servir directement les fichiers statiques.
- `.github/workflows/pages.yml` : publication automatique sur GitHub Pages.
- `404.html` : page d'erreur GitHub Pages.

## Modifier le site

### Modifier les textes
Ouvre `index.html` et recherche le titre ou la section à modifier.

### Modifier l'apparence
Ouvre `css/sabi.css`. Les variables en haut du fichier permettent de modifier rapidement les couleurs, espacements et tailles.

### Modifier les fonctions
Ouvre `js/sabi.js`. Les constantes au début du fichier permettent notamment d'adapter les clés de stockage et le code local initial.

## Publier sur GitHub

1. Crée un nouveau dépôt GitHub.
2. Envoie **tout le contenu de ce dossier**, pas le dossier parent lui-même.
3. Va dans `Settings` → `Pages`.
4. Choisis `GitHub Actions` comme source si tu utilises le workflow fourni.
5. Le workflow publiera automatiquement le site à chaque modification de la branche principale.

Alternative simple : dans `Settings` → `Pages`, choisis `Deploy from a branch`, sélectionne `main` et le dossier `/ (root)`.

## Important

Le site est entièrement statique. Les dossiers, rapports, messages et préférences sont stockés dans le navigateur avec `localStorage`/`sessionStorage`. Ils ne sont donc pas partagés automatiquement entre visiteurs.

Pour une utilisation multi-utilisateur avec comptes, permissions et données communes, il faudra connecter une base de données et une authentification.
