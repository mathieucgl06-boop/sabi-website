(() => {
  const CASE_PREFIX='sabi_case_';
  const REPORT_PREFIX='sabi_report_';
  const MSG_PREFIX='sabi_msg_';
  const NOTIF_KEY='sabi_notifications';
  const COUNTER_KEY='sabi_counter';
  const REPORT_COUNTER_KEY='sabi_report_counter';
  const AGENT_KEY='sabi_agent_session';
  const THEME_KEY='sabi_theme';
  // Code local initial. Il est modifiable dans le navigateur via les données locales.
  const DEFAULT_PIN='2468';

  const $=id=>document.getElementById(id);
  const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  const now=()=>new Date().toLocaleString('fr-FR');
  const isoDate=()=>new Date().toISOString().slice(0,10);

  function toast(msg){
    const t=$('toast'); if(!t)return;
    t.textContent=msg;t.style.display='block';
    clearTimeout(window.__toast);window.__toast=setTimeout(()=>t.style.display='none',3200);
  }
  function toggleMenu(){$('nav').classList.toggle('open')}
  window.toggleMenu=toggleMenu;

  function loadCases(){
    const a=[];
    for(let i=0;i<localStorage.length;i++){
      const k=localStorage.key(i);
      if(!k?.startsWith(CASE_PREFIX))continue;
      try{const d=JSON.parse(localStorage.getItem(k));if(d?.id)a.push(d)}catch{}
    }
    return a.sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
  }
  function saveCase(d){localStorage.setItem(CASE_PREFIX+d.id,JSON.stringify(d))}
  function nextCaseId(){
    const y=new Date().getFullYear();let n=parseInt(localStorage.getItem(COUNTER_KEY)||'0',10);
    if(!Number.isFinite(n))n=0;
    let id;
    do{n++;id=`SABI-${y}-${String(n).padStart(4,'0')}`}while(localStorage.getItem(CASE_PREFIX+id));
    localStorage.setItem(COUNTER_KEY,String(n));return id;
  }
  function nextReportId(){
    const y=new Date().getFullYear();let n=parseInt(localStorage.getItem(REPORT_COUNTER_KEY)||'0',10)+1;
    localStorage.setItem(REPORT_COUNTER_KEY,String(n));return `RPT-${y}-${String(n).padStart(4,'0')}`;
  }
  function addNotification(title,text,type='info'){
    let list=[];try{list=JSON.parse(localStorage.getItem(NOTIF_KEY)||'[]')}catch{}
    list.unshift({id:crypto.randomUUID?.()||String(Date.now()),title,text,type,date:now(),read:false});
    localStorage.setItem(NOTIF_KEY,JSON.stringify(list.slice(0,50)));renderNotifications();
  }
  function getNotifications(){try{return JSON.parse(localStorage.getItem(NOTIF_KEY)||'[]')}catch{return[]}}

  function statusPill(status){return `<span class="pill">${esc(String(status).toUpperCase())}</span>`}
  function caseSummary(c){
    return `<div class="case-row">
      <div><strong>${esc(c.id)}</strong><div class="case-meta">${esc(c.type)} · ${esc(c.conf)} · ${esc(c.status)} · ${esc(c.createdAt)}</div></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn small" type="button" onclick="viewCase('${esc(c.id)}')">Consulter</button><button class="btn small" type="button" onclick="editCase('${esc(c.id)}')">Modifier</button></div>
    </div>`;
  }

  window.viewCase=function(id){
    const c=loadCases().find(x=>x.id===id);if(!c)return;
    $('caseModalTitle').textContent=c.id;
    $('caseModalBody').innerHTML=`
      <div class="statusbar">${statusPill(c.status)}${statusPill(c.conf)}${statusPill(c.type)}</div>
      <p><b>Demandeur :</b> ${esc(c.name)}<br><b>Contact :</b> ${esc(c.contact)}<br><b>Créé le :</b> ${esc(c.createdAt)}</p>
      <div class="card" style="box-shadow:none;margin-top:14px"><b>Description</b><p>${esc(c.desc).replace(/\n/g,'<br>')}</p></div>
      <div class="card" style="box-shadow:none;margin-top:12px"><b>Éléments disponibles</b><p>${esc(c.elem||'Aucun élément renseigné').replace(/\n/g,'<br>')}</p></div>
      <div class="timeline" style="margin-top:24px">
        <div class="event"><b>Demande enregistrée</b><p>${esc(c.createdAt)}</p></div>
        <div class="event"><b>Dernière mise à jour</b><p>${esc(c.updatedAt||c.createdAt)}</p></div>
      </div>`;
    $('caseModal').classList.add('open');document.body.classList.add('no-scroll');
  };
  window.closeModal=function(){$('caseModal').classList.remove('open');document.body.classList.remove('no-scroll')};
  $('caseModal').addEventListener('click',e=>{if(e.target===$('caseModal'))closeModal()});

  window.editCase=function(id){
    const c=loadCases().find(x=>x.id===id);if(!c)return;
    $('caseModalTitle').textContent='Modifier '+c.id;
    $('caseModalBody').innerHTML=`
      <div class="form">
        <div class="field"><label>Statut</label><select id="editStatus"><option ${c.status==='En cours d’évaluation'?'selected':''}>En cours d’évaluation</option><option ${c.status==='En enquête'?'selected':''}>En enquête</option><option ${c.status==='En attente'?'selected':''}>En attente</option><option ${c.status==='Clôturé'?'selected':''}>Clôturé</option></select></div>
        <div class="field"><label>Confidentialité</label><select id="editConf"><option ${c.conf==='Standard'?'selected':''}>Standard</option><option ${c.conf==='Confidentiel'?'selected':''}>Confidentiel</option><option ${c.conf==='Très confidentiel'?'selected':''}>Très confidentiel</option></select></div>
        <div class="field full"><label>Note interne</label><textarea id="editNote" placeholder="Ajoute une note de suivi...">${esc(c.note||'')}</textarea></div>
        <div class="field full"><button class="btn primary" type="button" onclick="saveCaseEdit('${esc(c.id)}')">Enregistrer les modifications</button></div>
      </div>`;
    $('caseModal').classList.add('open');document.body.classList.add('no-scroll');
  };
  window.saveCaseEdit=function(id){
    const c=loadCases().find(x=>x.id===id);if(!c)return;
    const old=c.status;c.status=$('editStatus').value;c.conf=$('editConf').value;c.note=$('editNote').value;c.updatedAt=now();
    saveCase(c);closeModal();renderManagement();searchCases();updateDashboard();
    if(old!==c.status)addNotification('Statut mis à jour',`${id} est maintenant « ${c.status} ».`,'status');
    toast('Dossier mis à jour');
  };

  $('requestForm').addEventListener('submit',e=>{
    e.preventDefault();if(!e.currentTarget.reportValidity())return;
    const id=nextCaseId();
    const c={id,name:$('rname').value.trim(),contact:$('rcontact').value.trim(),type:$('rtype').value,conf:$('rconf').value,desc:$('rdesc').value.trim(),elem:$('relem').value.trim(),status:'En cours d’évaluation',createdAt:now(),updatedAt:now()};
    saveCase(c);
    $('requestResult').style.display='block';
    $('requestResult').innerHTML=`<div class="eyebrow">DOSSIER CRÉÉ</div><h3>${esc(id)}</h3><p style="color:var(--muted)">Conserve cette référence pour consulter le dossier sur cet appareil.</p><div class="statusbar">${statusPill(c.status)}${statusPill(c.type)}${statusPill(c.conf)}</div><div class="actions"><button class="btn small" type="button" onclick="viewCase('${esc(id)}')">Ouvrir le dossier</button></div>`;
    e.currentTarget.reset();$('trackId').value=id;renderManagement();searchCases();updateDashboard();
    addNotification('Nouveau dossier',`Le dossier ${id} a été créé.`,'new');toast(`Dossier ${id} créé`);
  });

  window.searchCases=function(){
    const q=($('trackId').value||'').trim().toLowerCase(),s=$('trackStatus').value,t=$('trackType').value;
    const list=loadCases().filter(c=>(!q||JSON.stringify(c).toLowerCase().includes(q))&&(!s||c.status===s)&&(!t||c.type===t));
    $('caseList').innerHTML=list.length?list.map(caseSummary).join(''):'<div class="empty">Aucun dossier ne correspond à cette recherche.</div>';
    if(q && /^SABI-\d{4}-\d{4}$/.test(q.toUpperCase()) && list[0] && list[0].id===q.toUpperCase()) viewCase(list[0].id);
  };

  window.renderManagement=function(){
    const q=($('manageSearch').value||'').trim().toLowerCase(),s=$('manageStatus').value,c= $('manageConf').value;
    const list=loadCases().filter(x=>(!q||JSON.stringify(x).toLowerCase().includes(q))&&(!s||x.status===s)&&(!c||x.conf===c));
    $('managementList').innerHTML=list.length?list.map(caseSummary).join(''):'<div class="empty">Aucun dossier enregistré.</div>';
  };

  function loadReports(){
    const a=[];
    for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(!k?.startsWith(REPORT_PREFIX))continue;try{const d=JSON.parse(localStorage.getItem(k));if(d?.id)a.push(d)}catch{}}
    return a.sort((a,b)=>String(b.date).localeCompare(String(a.date)));
  }
  function renderReports(){
    const a=loadReports();
    $('reportList').innerHTML=a.length?a.map(r=>`<div class="report-card"><div class="report-head"><div><strong>${esc(r.id)}</strong><div class="case-meta">${esc(r.type)} · ${esc(r.date)} · Dossier ${esc(r.caseId||'non associé')}</div></div><button class="btn small" onclick="viewReport('${esc(r.id)}')">Consulter</button></div><h3>${esc(r.title)}</h3><p>${esc(r.body).slice(0,500)}${r.body.length>500?'…':''}</p></div>`).join(''):'<div class="empty">Aucun rapport enregistré.</div>';
  }
  window.viewReport=function(id){
    const r=loadReports().find(x=>x.id===id);if(!r)return;
    $('caseModalTitle').textContent=r.id;
    $('caseModalBody').innerHTML=`<div class="statusbar">${statusPill(r.type)}${r.caseId?statusPill(r.caseId):''}</div><p><b>Rédacteur :</b> ${esc(r.author)}<br><b>Date :</b> ${esc(r.date)}<br><b>Objet :</b> ${esc(r.title)}</p><div class="card" style="box-shadow:none;margin-top:14px"><p>${esc(r.body).replace(/\n/g,'<br>')}</p></div>`;
    $('caseModal').classList.add('open');document.body.classList.add('no-scroll');
  };
  $('reportDate').value=isoDate();
  $('reportForm').addEventListener('submit',e=>{
    e.preventDefault();if(!e.currentTarget.reportValidity())return;
    const id=nextReportId();
    const r={id,caseId:$('reportCase').value.trim().toUpperCase(),author:$('reportAuthor').value.trim(),type:$('reportType').value,date:$('reportDate').value||isoDate(),title:$('reportTitle').value.trim(),body:$('reportBody').value.trim()};
    localStorage.setItem(REPORT_PREFIX+id,JSON.stringify(r));e.currentTarget.reset();$('reportDate').value=isoDate();renderReports();
    addNotification('Nouveau rapport',`Le rapport ${id} a été enregistré.`,'report');toast(`Rapport ${id} enregistré`);
  });

  function updateDashboard(){
    const a=loadCases();
    $('dashTotal').textContent=a.length;$('dashReview').textContent=a.filter(x=>x.status==='En cours d’évaluation').length;
    $('dashInvest').textContent=a.filter(x=>x.status==='En enquête').length;$('dashClosed').textContent=a.filter(x=>x.status==='Clôturé').length;
  }
  function renderNotifications(){
    const a=getNotifications();
    $('notificationList').innerHTML=a.length?a.map(n=>`<div class="notification ${n.read?'':'unread'}"><span class="badge"></span><div><strong>${esc(n.title)}</strong><div class="case-meta">${esc(n.date)}</div><p style="margin:5px 0;color:var(--muted);font-size:13px">${esc(n.text)}</p></div></div>`).join(''):'<div class="empty">Aucune notification.</div>';
  }

  window.loginAgent=function(){
    const pin=$('agentPin').value.trim();
    const stored=localStorage.getItem('sabi_agent_pin')||DEFAULT_PIN;
    if(pin!==stored){toast('Code d’accès incorrect');return}
    sessionStorage.setItem(AGENT_KEY,'1');$('agentLogin').style.display='none';$('agentPanel').style.display='block';updateDashboard();toast('Espace agents ouvert');
  };
  window.logoutAgent=function(){sessionStorage.removeItem(AGENT_KEY);$('agentLogin').style.display='block';$('agentPanel').style.display='none';$('agentPin').value='';toast('Session fermée')};
  function restoreSession(){if(sessionStorage.getItem(AGENT_KEY)==='1'){ $('agentLogin').style.display='none';$('agentPanel').style.display='block';}}
  window.scrollToId=id=>document.getElementById(id)?.scrollIntoView({behavior:'smooth'});

  window.exportData=function(){
    const cases=loadCases(),reports=loadReports(),notifications=getNotifications(),messages=[];
    for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k?.startsWith(MSG_PREFIX)){try{messages.push(JSON.parse(localStorage.getItem(k)))}catch{}}}
    const payload={format:'SABI-LOCAL-1',exportedAt:new Date().toISOString(),cases,reports,notifications,messages};
    const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`sabi-sauvegarde-${isoDate()}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);toast('Sauvegarde exportée');
  };
  window.importData=function(ev){
    const f=ev.target.files?.[0];if(!f)return;
    const reader=new FileReader();
    reader.onload=()=>{
      try{
        const p=JSON.parse(reader.result);if(p.format!=='SABI-LOCAL-1')throw new Error('format');
        (p.cases||[]).forEach(c=>{if(c?.id)localStorage.setItem(CASE_PREFIX+c.id,JSON.stringify(c))});
        (p.reports||[]).forEach(r=>{if(r?.id)localStorage.setItem(REPORT_PREFIX+r.id,JSON.stringify(r))});
        if(Array.isArray(p.notifications))localStorage.setItem(NOTIF_KEY,JSON.stringify(p.notifications));
        (p.messages||[]).forEach(m=>{if(m?.id)localStorage.setItem(MSG_PREFIX+m.id,JSON.stringify(m))});
        renderManagement();renderReports();renderNotifications();updateDashboard();searchCases();toast('Sauvegarde importée');
      }catch{toast('Fichier de sauvegarde invalide')}
      ev.target.value='';
    };reader.readAsText(f);
  };
  window.clearAllData=function(){
    if(!confirm('Effacer tous les dossiers, rapports et messages enregistrés sur cet appareil ?'))return;
    Object.keys(localStorage).filter(k=>k.startsWith('sabi_')).forEach(k=>localStorage.removeItem(k));
    renderManagement();renderReports();renderNotifications();updateDashboard();searchCases();toast('Données locales effacées');
  };

  $('contactForm').addEventListener('submit',e=>{
    e.preventDefault();if(!e.currentTarget.reportValidity())return;
    const id='MSG-'+Date.now();
    localStorage.setItem(MSG_PREFIX+id,JSON.stringify({id,name:$('cname').value.trim(),subject:$('csubject').value.trim(),email:$('cemail').value.trim(),message:$('cmessage').value.trim(),date:now()}));
    addNotification('Nouveau message',`Message reçu : ${$('csubject').value.trim()}.`,'message');
    e.currentTarget.reset();toast('Message enregistré');
  });

  $('themeBtn').addEventListener('click',()=>{
    const light=document.documentElement.classList.toggle('light');
    localStorage.setItem(THEME_KEY,light?'light':'dark');$('themeBtn').textContent=light?'☀':'☾';
  });
  if(localStorage.getItem(THEME_KEY)==='light'){document.documentElement.classList.add('light');$('themeBtn').textContent='☀'}
  ['manageSearch','manageStatus','manageConf'].forEach(id=>$(id).addEventListener('input',renderManagement));
  $('trackId').addEventListener('keydown',e=>{if(e.key==='Enter')searchCases()});
  restoreSession();renderManagement();renderReports();renderNotifications();updateDashboard();searchCases();
})();
